package com.codlex.jsms.client.gui.paneli;

import java.awt.BorderLayout;

import javax.swing.JPanel;

public class PanelSaBorderLejautom extends JPanel {
	private static final long serialVersionUID = 1L;
	public PanelSaBorderLejautom() {
		this.setLayout(new BorderLayout());
	}
}
