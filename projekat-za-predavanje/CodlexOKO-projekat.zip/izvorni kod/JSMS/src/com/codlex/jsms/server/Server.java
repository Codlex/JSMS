package com.codlex.jsms.server;

/**
 * Oznacava da je svaki server zaseban tred i koristi se kao generican tip.
 * 
 * @author Dejan Pekter RN 13/11 <dpekter11@raf.edu.rs>
 *
 */

public interface Server extends Runnable {
}
